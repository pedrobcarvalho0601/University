#ifndef FUNCOES_H
#define FUNCOES_H

class funcoes
{
public:
    funcoes();
    void getescolha();

    int escolha;
};

#endif // FUNCOES_H
