#include "funcoes.h"
#include "mensagens.h"
#include <iostream>
#include <algorithm>
#include <cctype>

/*
funcoes::funcoes() {}

bool isNumber(const std::string &s) {
    return !s.empty() && all_of(s.begin(), s.end(), ::isdigit);
}

void funcoes::getescolha() {
    mensagens mensagem;
    std::string input; // Variável temporária para armazenar o input do usuário

    while (true) {
        std::cin >> input;

        // Verifica se o input é um número
        if (!isNumber(input)) {
            mensagem.entradaInvalida();
        } else {
            escolha = stoi(input);
            break; // Sai do loop se o input for um número válido
        }
    }
}
*/
